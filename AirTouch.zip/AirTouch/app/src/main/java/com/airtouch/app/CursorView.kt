package com.airtouch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Full-screen, touch-transparent view that draws the floating circle. */
class CursorView(ctx: Context) : View(ctx) {
    @Volatile var nx = 0.5f
    @Volatile var ny = 0.5f
    @Volatile var radiusPx = 40f
    @Volatile var state = 0          // 0 hovering, 1 touching, 2 holding
    @Volatile var shown = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 10f; color = Color.argb(110, 0, 0, 0)
    }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val x = nx * width
        val y = ny * height
        val r: Float
        when (state) {
            1 -> { r = radiusPx * 0.65f; fill.color = Color.argb(180, 46, 204, 113) }
            2 -> { r = radiusPx * 0.80f; fill.color = Color.argb(180, 255, 152, 0) }
            else -> { r = radiusPx; fill.color = Color.argb(90, 48, 176, 255) }
        }
        c.drawCircle(x, y, r, fill)
        c.drawCircle(x, y, r, shadow)
        c.drawCircle(x, y, r, ring)
        c.drawCircle(x, y, 4f, ring)
    }
}
