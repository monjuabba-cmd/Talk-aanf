package com.airtouch.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Two jobs, both of which work on top of every other app:
 *  1. draws the cursor circle (accessibility overlay - no extra permission needed)
 *  2. performs taps / long-presses / swipes on the real screen
 */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureService? = null

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val cn = ComponentName(ctx, GestureService::class.java)
            return enabled.split(':').any {
                it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var cursor: CursorView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
    }

    private fun addOverlay() {
        if (cursor != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = CursorView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        manager.addView(view, lp)
        wm = manager
        cursor = view
    }

    private fun removeOverlay() {
        cursor?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        cursor = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeOverlay()
        super.onDestroy()
    }

    // ---- cursor -----------------------------------------------------------------------------

    fun screenW(): Int = cursor?.width ?: 0
    fun screenH(): Int = cursor?.height ?: 0

    fun moveCursor(nx: Float, ny: Float, state: Int, radiusPx: Float, visible: Boolean) {
        val c = cursor ?: return
        c.nx = nx; c.ny = ny; c.state = state; c.radiusPx = radiusPx; c.shown = visible
        c.postInvalidate()
    }

    fun hideCursor() {
        val c = cursor ?: return
        c.shown = false
        c.postInvalidate()
    }

    // ---- gestures (coordinates are 0..1 of the screen) --------------------------------------

    private fun ready() = screenW() > 10 && screenH() > 10
    private fun px(n: Float) = (n * screenW()).coerceIn(2f, screenW() - 2f)
    private fun py(n: Float) = (n * screenH()).coerceIn(2f, screenH() - 2f)

    fun tap(nx: Float, ny: Float) {
        if (!ready()) return
        send(Path().apply { moveTo(px(nx), py(ny)) }, 50)
    }

    fun longPress(nx: Float, ny: Float) {
        if (!ready()) return
        send(Path().apply { moveTo(px(nx), py(ny)) }, 700)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        if (!ready()) return
        send(Path().apply { moveTo(px(x1), py(y1)); lineTo(px(x2), py(y2)) }, durationMs)
    }

    private fun send(path: Path, durationMs: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        main.post { dispatchGesture(g, null, null) }
    }
}
